var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwz",
  1: "aginptv",
  2: "p",
  3: "abcdefghilmnopqrstuw",
  4: "_abcdefghilmnopqrstuvwz",
  5: "ag",
  6: "acdefghilmnptv",
  7: "dt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties",
  7: "Pages"
};

