var searchData=
[
  ['populateai',['populateAI',['../class_game_manager.html#ace766fd970b0dcd1f01570a2a568d359',1,'GameManager']]],
  ['progressinfection',['progressInfection',['../class_infection.html#a11f32faf89dc01aaa2c99d868f087654',1,'Infection']]]
];
