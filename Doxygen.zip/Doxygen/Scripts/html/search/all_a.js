var searchData=
[
  ['onmousedown',['OnMouseDown',['../class_infection.html#aacb6d38baaed331a343605636489bdfc',1,'Infection']]],
  ['ontriggerenter2d',['OnTriggerEnter2D',['../class_infection.html#ae1f64ed87a131ba1e087879e26b09995',1,'Infection.OnTriggerEnter2D()'],['../class_player_mobility.html#af8e40691ed764a0439acf1d1cb7f2209',1,'PlayerMobility.OnTriggerEnter2D()']]]
];
