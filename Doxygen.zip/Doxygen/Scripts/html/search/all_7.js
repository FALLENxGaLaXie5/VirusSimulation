var searchData=
[
  ['infection',['Infection',['../class_infection.html',1,'']]]
];
